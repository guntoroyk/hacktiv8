     /*
=============
TUG OF WAR WINNER
=============
Name :_____________
[INSTRUCTIONS]
Tug of War adalah sebuah function yang menerima string sebagai tarik tambang antara 2 belah pihak
Kamu harus bisa menentukan pemenang dari permainan tarik tambang ini dengan cara mengukur kekuatan setiap pemain
Kekuatan pemain ada 3 Level 
  - A = 1 
  - B = 2
  - C = 3

Sisi dengan kekuatan terbanyak akan menang dan jika kekuatannya sama maka hasilnya akan draw

[CONSTRAINTS]
Tidak ada batasan untuk soal ini.

[EXAMPLE]
tugOfWar('ABCA--V--ABCC')
Skor team kiri: 7
Skor team kanan: 9
output: Team KANAN Menang!

[Tulis PSEUDOCODE di bawah ini]

function tugOfWar(sentence) {
 READ & RESTORE result =0
 READ & RESTORE temp =[]
 READ & RESTORE temp2 = []

FOR var i=0;i<sentence.length;i++

PUSH temp FROM sentence.split('-')


// Nilai tidak valid (0) jika logic dan PSEUDOCODE berbeda!
// Tidak harus formal pseudocode, tapi paling tidak jelaskan step by step logikanya
*/

function tugOfWar(sentence) {
 var newSentence = sentence.split('--V--')
//  console.log(newSentence)
 var countSentence =[]
var flag =false

 if(newSentence === undefined){
   flag = false
 }else{
 for(i=0;i<newSentence.length;i++){
   var count =0
   for(j=0;j<newSentence[i].length;j++){
     if(newSentence[i][j] === 'A'){
       count++
     
     }
     else if(newSentence[i][j] === 'B'){
       count +=2
     
     }
     else if(newSentence[i][j] === 'C'){
       count +=3
    
     }
     flag = true
   }
   countSentence.push(count)
 }
 console.log(countSentence)
if(flag){
   if(countSentence[0]>countSentence[1]){
     return 'Team Kiri menang'
   }else if(countSentence[0]< countSentence[1]){
     return 'Team Kanan menang'
   }else if(countSentence[0] === countSentence [1]){
     return 'DRAW'
}
}else{
  return 'NO PLAYER'
}
}
}
 


console.log(tugOfWar('--V--C')); // "Team KANAN Menang!"
console.log(tugOfWar('CC--V--AAAA')); // "Team Kiri Menang!"
console.log(tugOfWar('BBBB--V--CCC')); // "Team KANAN Menang!"
console.log(tugOfWar('AAAA--V--CA')); // 'DRAW'
console.log(tugOfWar('--V--')); // 'NO PLAYERS