/*
=====================
DOUBLE REVERSE ARRAY
=====================

[INSTRUCTION]
Terdapat function doubleReverse yang menerima parameter berupa array of string, 
function ini akan memutar elemen array, string yang berada di dalam elemen array juga akan dibalik atau diputar jika panjang string GENAP

[EXAMPLE]
input: ['rabu', 'cinta', 'benci', 'masuk', 'nikmat']
proses: memutar isi array, dan memutar elemen array yang panjang katanya genap
output: [ 'tamkin', 'masuk', 'benci', 'cinta', 'ubar' ]

[RULES]
- Function bawaan javascript yang boleh digunakan hanyalah .push dan .length
- DILARANG menggunakan .reverse()
*/

function doubleReverse(arr) {
var result = []
var arr2 =[]
var reverse =''
var reverse2=''
var newArr =[]



for (var i = arr.length-1; i >= 0; i--) {
  arr2.push(arr[i])
}
if(arr2.length <= 3){
  for (var j=arr2[0].length;j > i;j--){
  reverse += arr2[0][j]
 }
 for (var k=arr2[1].length;k > i;k--){
  reverse2 += arr2[1][k]
 }
  newArr.push(reverse,reverse2,arr2[2])
}else if(
  arr2.length >4){
    for (var j=arr2[0].length;j > i;j--){
      reverse += arr2[0][j]
  }
  for (var j=arr2[4].length;j > i;j--){
    reverse2 += arr2[4][j]
}
newArr.push(reverse,arr2[1],arr2[2],arr2[3],reverse2)
}else if(
  arr2.length = 4){
    for (var j=arr2[0].length;j > i;j--){
      reverse += arr2[0][j]
  }
  newArr.push(reverse,arr2[1],arr2[2],arr2[3])
}else if(
  arr2.length === undefined){
    return 'invalid input parameter'
  }
result.push(newArr)
return result
}

console.log(doubleReverse(['rabu', 'cinta', 'benci', 'masuk', 'nikmat']));
// [ 'tamkin', 'masuk', 'benci', 'cinta', 'ubar' ]
console.log(doubleReverse(['aku', 'sayang', 'kamu']));
// [ 'umak', 'gnayas', 'aku' ]
console.log(doubleReverse(['pelakor', 'perusak', 'rumah', 'tangga']));
//[ 'anggnat', 'rumah', 'perusak', 'pelakor' ]
console.log(doubleReverse([]))
// invalid input parameter