/*
=========
HACKATHON
=========

[INSTRUCTION]
Buatlah suatu aplikasi untuk membuat catatan ekonomi.

[EXAMPLE]
"bank account sudah disediakan"

input: [['Jeff Bezos+5%', 'Larry Page+10%', 'Jeff Bezos-3%'], ['Larry Page+2%', 'Larry Page-1%']]
process:
  bank account => deposit atas nama Jeff Bezos ditambah 5%, menjadi 105000
  bank account => deposit atas nama Larry Page ditambah 10%, mejadi  104500
  bank account => deposit atas nama Jeff Bezos dikurangi 3%, mejadi 101850
  ...dst
output:
  [
    { name: 'Jeff Bezos', deposit: 105000, owner: 'Amazon' },
    { name: 'Larry Page', deposit: 104500, owner: 'Google' },
    { name: 'Jeff Bezos', deposit: 101850, owner: 'Amazon' },
    { name: 'Larry Page', deposit: 106590, owner: 'Google' },
    { name: 'Larry Page', deposit: 105524.1, owner: 'Google' }
  ]

[RULES]
- Dilarang menggunakan .indexOf(), .split(), .filter(), .map(), dan .slice()
*/

function manualSlice(start, finish, text) {
  var result = '';
  for (var i = start; i < finish; i++) {
    result += text[i];
  }
  return result;
}

function singleSplit(symbol, string) {
  var result = [];
  var text = '';
  for (var i = 0; i < string.length; i++) {
    if (i === string.length - 1) {
      text += string[i];
      result.push(text);
    } else if (string[i] === symbol) {
      result.push(text);
      text = '';
    } else {
      text += string[i];
    }
  }
  return result;
}

function economyChangeSummary(tradeActivity) {
  var bankAccount = [
    { name: 'Jeff Bezos', deposit: 100000, owner: 'Amazon' },
    { name: 'Jack Ma', deposit: 90000, owner: 'Alibaba' },
    { name: 'Larry Page', deposit: 95000, owner: 'Google' }
  ];
  // YOUR CODE GOES HERE
  var result = [];
  for (var i = 0; i < tradeActivity.length; i++) {
    for (var j = 0; j < tradeActivity[i].length; j++) {
      var symbol = '+';
      var splitTrade = singleSplit(symbol, tradeActivity[i][j]);
      if (splitTrade.length < 2) {
        symbol = '-';
        splitTrade = singleSplit(symbol, tradeActivity[i][j]);
      }
      var angka = symbol + manualSlice(0, splitTrade[1].length - 1, splitTrade[1]);
      angka = Number(angka);
      var nama = splitTrade[0];
      for (var k = 0; k < bankAccount.length; k++) {
        if (nama === bankAccount[k].name) {
          bankAccount[k].deposit += bankAccount[k].deposit * angka / 100;
          result.push({
            name: nama,
            deposit: bankAccount[k].deposit,
            owner: bankAccount[k].owner
          })
        }
      }
    }
  }
  return result;
};

console.log(economyChangeSummary([['Jeff Bezos+5%', 'Larry Page+10%', 'Jeff Bezos-3%'], ['Larry Page+2%', 'Larry Page-1%'], ['Jack Ma+4%'], ['Larry Page-8%', 'Jack Ma+20%', 'Jeff Bezos-3%', 'Jeff Bezos+8%']]));
/* 
  [ { name: 'Jeff Bezos', deposit: 105000, owner: 'Amazon' },
  { name: 'Larry Page', deposit: 104500, owner: 'Google' },
  { name: 'Jeff Bezos', deposit: 101850, owner: 'Amazon' },
  { name: 'Larry Page', deposit: 106590, owner: 'Google' },
  { name: 'Larry Page', deposit: 105524.1, owner: 'Google' },
  { name: 'Jack Ma', deposit: 93600, owner: 'Alibaba' },
  { name: 'Larry Page', deposit: 97082.172, owner: 'Google' },
  { name: 'Jack Ma', deposit: 112320, owner: 'Alibaba' },
  { name: 'Jeff Bezos', deposit: 98794.5, owner: 'Amazon' },
  { name: 'Jeff Bezos', deposit: 106698.06, owner: 'Amazon' } ]
*/

console.log(economyChangeSummary([['Jeff Bezos-10%']]))
/*
  [ { name: 'Jeff Bezos', deposit: 90000, owner: 'Amazon' } ]
*/